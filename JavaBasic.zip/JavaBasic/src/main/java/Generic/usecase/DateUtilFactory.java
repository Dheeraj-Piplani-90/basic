package Generic.usecase;

import java.util.Date;

public class DateUtilFactory<T extends  DateUtil> {

    T obj;

    public DateUtilFactory(T obj) {
        this.obj = obj;
    }

    public String getStringDate(Date date){
       return obj.extractDate(date);
    }




    public static void main(String[] args) {
        Ddmmyy ddmmyy=new Ddmmyy();
        DateUtilFactory<Ddmmyy> ddmmyyDateUtilFactory=new DateUtilFactory<>(ddmmyy);
        System.out.println( ddmmyyDateUtilFactory.getStringDate(new Date()));


        Mmddyyyy mmddyyyy=new Mmddyyyy();
        DateUtilFactory<Mmddyyyy> ddmmyyDateUtilFactory1=new DateUtilFactory<>(mmddyyyy);
        System.out.println( ddmmyyDateUtilFactory1.getStringDate(new Date()));
    }
}
