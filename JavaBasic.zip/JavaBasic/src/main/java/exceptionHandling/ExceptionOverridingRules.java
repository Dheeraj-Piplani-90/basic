package exceptionHandling;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

public class ExceptionOverridingRules {

    public class Parent{
        public void print()  throws Exception  {
            System.out.println("Parent");
        }
    }


    public  class  Child extends Parent{
        public  void print()  throws FileNotFoundException  {
            System.out.println("Child");
        }
    }
}
