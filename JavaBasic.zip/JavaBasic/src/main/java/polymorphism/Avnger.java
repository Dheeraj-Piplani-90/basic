package polymorphism;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;

public class Avnger implements Serializable {

    public int chainCount=2;
//    public Integer chainCount=new Integer(1);

    public void printHello()  {
        System.out.println("Avenger");
    }

    public static void main(String[] args) {
        Avnger s=new Avnger();
//        Bike bike=new Avnger();
//        s.printHello();
//        bike.printHello();
    }
}
