package varun;

public class Hero extends Bike {

}
