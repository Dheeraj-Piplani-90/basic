package thread;

public class AnotherJoinThread extends Thread{

    public void run(){
        for(int i=0;i<=20000;i++){
            System.out.println(Thread.currentThread().getName()+" is running");
        }
    }


    public static void main(String[] args) throws Exception{
        AnotherJoinThread anotherThread=new AnotherJoinThread();
        anotherThread.start();
//        Thread.sleep(1000);


        AnotherJoinThread anotherThread2=new AnotherJoinThread();
        anotherThread2.start();
        anotherThread2.join();
    }
}