package hashset;

import java.util.HashSet;

public class Test {

    public static void main(String[] args) {
        HashSet<Integer> hashSet=new HashSet();
        hashSet.add(1);
        hashSet.add(2);
        hashSet.add(3);
        hashSet.add(4);
        hashSet.add(5);
        hashSet.add(4);
        System.out.println(hashSet.contains(4));
        System.out.println(hashSet.size());
    }
}
