import designPattern.builder.BankAccount;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

public class Test {

    public static void main(String[] args) throws ParseException {

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
//        formatter.setLenient(falsec);
//        Date date=formatter.parse("2021-04-31");
//        System.out.println(date);


        String x="abcdefjhijz";
        char[] y=x.toCharArray();
        for(int i=0;i<y.length;i++){
            System.out.println((int)y[i]);
        }

    }

}
