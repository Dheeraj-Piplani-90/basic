package interview.stack;

import java.util.Stack;

public class NextLargestElement {

    public static void main(String[] args) {

        int[] input={2,1,5,4,6};
        findNLE(input);
    }


    public static void findNLE(int[] input) {

        Stack<Integer> stack = new Stack<>();
        stack.push(input[0]);
        for (int i = 1; i <= input.length - 1; i++) {
            if (!stack.isEmpty()) {
                int ele = stack.pop();

                while (ele < input[i]) {
                    System.out.println("Elements  (" + ele + "_--->" + input[i]);
                    if(stack.isEmpty())
                        break;
                    ele = stack.pop();
                }


                if (ele > input[i]) {
                    stack.push(ele);
                }
                stack.push(input[i]);
            }
        }


    }


}
