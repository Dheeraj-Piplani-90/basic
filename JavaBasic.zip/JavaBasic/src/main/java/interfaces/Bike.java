package interfaces;

public interface Bike {
    void pringName();
}
