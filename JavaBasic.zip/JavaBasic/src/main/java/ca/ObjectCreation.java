package ca;

import java.lang.reflect.InvocationTargetException;

public class ObjectCreation {

    public void printHello() {
        System.out.println("Hello");
    }


    public static void main(String[] args) throws IllegalAccessException, InstantiationException, ClassNotFoundException, NoSuchMethodException, InvocationTargetException {
        ObjectCreation objectCreation1=new ObjectCreation();
        objectCreation1.printHello();


        ObjectCreation objectCreation2=ObjectCreation.class.newInstance();
        objectCreation2.printHello();


        Class objectCreation3=  Class.forName("ca.ObjectCreation");
        objectCreation3.newInstance();


        ObjectCreation objectCreation4=(ObjectCreation) Class.forName("ca.ObjectCreation").getConstructor().newInstance();
        objectCreation4.printHello();


    }
}
