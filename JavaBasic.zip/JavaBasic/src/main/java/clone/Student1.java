package clone;

public class Student1 {
    int age=2;

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
