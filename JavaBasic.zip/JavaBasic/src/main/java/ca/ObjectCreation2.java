package ca;

import java.lang.reflect.InvocationTargetException;

public class ObjectCreation2 implements ObjectCreateInterface {

    public void printHello(){
        System.out.println("Hello2");
    }



    public static void main(String[] args) throws IllegalAccessException, InstantiationException, ClassNotFoundException, NoSuchMethodException, InvocationTargetException {
        ObjectCreation2 objectCreation1=new ObjectCreation2();
        objectCreation1.printHello();

        ObjectCreation2 objectCreation2= ObjectCreation2.class.newInstance();
        objectCreation2.printHello();

        ObjectCreation2 objectCreation3= (ObjectCreation2) Class.forName("ca.ObjectCreation2").newInstance();
        objectCreation3.printHello();

            ObjectCreation2 objectCreation4=(ObjectCreation2) Class.forName("ca.ObjectCreation2").getConstructor().newInstance();
        objectCreation4.printHello();



    }
}
