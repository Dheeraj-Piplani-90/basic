package ca;

public interface ObjectCreateInterface {
    public void printHello();
}
