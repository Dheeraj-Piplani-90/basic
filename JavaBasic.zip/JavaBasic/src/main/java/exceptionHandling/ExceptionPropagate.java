package exceptionHandling;

public class ExceptionPropagate {

    public static void main(String[] args) {
        ExceptionThrowTest exceptionThrowTest=new ExceptionThrowTest();
        try {
            exceptionThrowTest.print();
        }
        catch (ArithmeticException e){
            System.out.println("Hello");
        }

    }
}
