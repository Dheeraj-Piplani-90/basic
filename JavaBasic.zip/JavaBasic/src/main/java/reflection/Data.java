package reflection;

public class Data {

    public String getDate(String tableName,String columnName){
        String x="Select"+columnName+" from "+tableName;
        return x;
    }
}
