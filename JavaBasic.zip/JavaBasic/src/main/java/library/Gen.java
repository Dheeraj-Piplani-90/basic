package library;

public class Gen<T> {

    public T t;

//    public void print();

}
