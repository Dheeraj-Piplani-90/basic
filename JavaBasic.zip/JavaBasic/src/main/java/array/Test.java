package array;

public class Test {
    int x=0;

    public void hello(){
        int x=0;
        x=1;
    }

    public  void pringHello(){
        System.out.println(x);
    }

    public static void main(String[] args) {
        Test test=new Test();
        test.hello();
        test.pringHello();
    }
}
