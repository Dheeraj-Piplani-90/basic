package hasmap;



public class Student {

    private int age;
    private int name;
    private int gender;
    private int marks;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Student student = (Student) o;
        return age == student.age &&
                name == student.name &&
                gender == student.gender &&
                marks == student.marks;
    }

// 12,varun,M,20
    // 20,varun,M,12




    @Override
    public int hashCode() {
        return age+name+gender+marks;
    }
}
