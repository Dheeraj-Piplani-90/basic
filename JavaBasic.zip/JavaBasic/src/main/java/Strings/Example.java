package Strings;

public class Example {
    private static final String x="y";

    public static void main(String[] args) {
        String s1 = "abc";
        String s2 = "abc";
        s1="xy";
        String s3= new String("acc");
        System.out.println((s1==s2));
        System.out.println((s1==s3));
        System.out.println((s1.equals(s3)));
    }



    private  void accesDriver(String url){


    }
}
