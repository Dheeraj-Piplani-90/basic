package Generic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Varun {

    ArrayList obj;

    public Varun(ArrayList obj) {
        this.obj = obj;
    }

    public void print(){
        int sum=0;
        for(Object t:obj){
            if(t instanceof  Integer){
                sum=sum+(Integer) t;
            }

        }
    }

}
