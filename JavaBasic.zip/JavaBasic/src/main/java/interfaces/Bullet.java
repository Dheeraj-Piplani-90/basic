package interfaces;

public class Bullet implements Bike  {

    public void pringName(){
        System.out.println("My name is Bullet");
    }
}
