package interfaces;

public class Honda implements  Bike {
    public void pringName() {
        System.out.println("my nae is honda");
    }
}
