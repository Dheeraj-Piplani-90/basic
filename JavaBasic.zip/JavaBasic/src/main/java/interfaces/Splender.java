package interfaces;

public class Splender implements Bike  {

    public void pringName(){
        System.out.println("My name is Splender");
    }
}

