package seriliaze;

class Demo implements java.io.Serializable
{
    private static final long serialVersionUID=1L;

    public int a;
    public String b;
    public  int y;
    public  int x=10;
    static int d=10;
    transient char c;

    // Default constructor
    public Demo(int a, String b,char c)
    {
        this.a = a;
        this.b = b;
        this.c=c;
    }

}