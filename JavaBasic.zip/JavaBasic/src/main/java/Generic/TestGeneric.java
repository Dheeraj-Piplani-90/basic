package Generic;

public class TestGeneric {
    public static void main(String[] args) {

    }


    public static void addAllElements(Gen gen){

    }
}
