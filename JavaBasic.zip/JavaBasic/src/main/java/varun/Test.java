package varun;

public class Test {

    public static void main(String[] args) {


        Bike bike=new Avenger();
        bike.printName();

        Hero hero=new Hero();
        hero.printName();

    }
}
