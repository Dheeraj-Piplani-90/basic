package thread;

public class AnotherThread implements Runnable{

    public void run() {
        System.out.println(Thread.currentThread().getName());
        System.out.println("Another imortant Thread");
    }

    public static void main(String[] args) {
        System.out.println(Thread.currentThread().getName());
        AnotherThread anotherThread=new AnotherThread();
        Thread thread=new Thread(anotherThread);
        thread.start();

    }


}
