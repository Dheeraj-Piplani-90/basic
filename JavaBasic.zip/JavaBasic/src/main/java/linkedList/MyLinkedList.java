package linkedList;

public class MyLinkedList {


    Node currentNode;
    Node firstNode;

    public MyLinkedList() {
    }


    public void insert(Object data){
        if(currentNode==null){
            Node node=new Node(data,null);
            currentNode=node;
            firstNode=node;
        }
        else {
            Node node=new Node(data,null);
            currentNode.setNext(node);
            currentNode=node;
        }
    }

    public static void main(String[] args) {
        MyLinkedList myLinkedList=new MyLinkedList();
        myLinkedList.insert("hello");
        myLinkedList.insert("hello1");
        myLinkedList.insert("hello2");
        System.out.println(myLinkedList);
    }
}
