package Generic;

import java.util.ArrayList;
import java.util.List;

public class Test {

    public static void main(String[] args) {
        List arrayList=new ArrayList<String>();
        arrayList.add("A");
        arrayList.add("B");
        arrayList.add("C");

//      Varun<String> varun=new Varun<String>(arrayList);
//      varun.print();



    }


    public static void sum(ArrayList<Integer> arrayList){
        int sum=0;
        for(Integer  o:arrayList){
            sum=sum+o;
        }
    }
}
