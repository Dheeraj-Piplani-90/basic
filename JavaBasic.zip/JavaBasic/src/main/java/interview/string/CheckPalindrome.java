package interview.string;

public class CheckPalindrome {


    public static void main(String[] args) {
         String a="abbbba";
        System.out.println(palindrome(a.toCharArray(),0,a.length()-1));
    }




    public static boolean palindrome(char[] str,int i,int j){

        if(i==j){
            return true;
        }
        if(str[i]==str[j] && (i+1==j)){
            return true;
        }
        if(str[i]==str[j]){
            return palindrome(str,i+1,j-1);
        }
        return false;
    }
}
