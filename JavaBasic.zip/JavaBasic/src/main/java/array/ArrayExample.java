package array;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class ArrayExample {


    public static void main(String[] args) {
        int[] a1=new int[45];
        a1=new int[90];
        System.out.println(a1[0]);
        System.out.println(a1[3]);
        a1[5]=  10;

LinkedList<Integer> linkedList=new LinkedList();
linkedList.add(2);
linkedList.add(3);
linkedList.add(5);
linkedList.add(4);
        Collections.sort(linkedList);
        System.out.println(linkedList);

   }



   public static void printAllElemnts(List list){
        for(Object o:list){
            System.out.println(o);
        }
   }

}
