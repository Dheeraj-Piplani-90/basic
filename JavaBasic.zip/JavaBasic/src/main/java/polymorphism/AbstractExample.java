package polymorphism;

public abstract class AbstractExample {

    public int x;

    public AbstractExample(int x){
        this.x=x;
    }

    public abstract void printHello();

    public void printBikeName(){
        System.out.println("Hello Bike");
    }
}
