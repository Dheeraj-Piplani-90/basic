package arrayList;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ArrayListTest {

    public static void main(String[] args) {

        List<Integer> rollNumberList=new ArrayList();
        rollNumberList.add(3);
        rollNumberList.add(3);
        rollNumberList.add(1);
        rollNumberList.add(5);
        rollNumberList.add(6);


        System.out.println("Before Sorting");
        for(Integer i:rollNumberList){
            System.out.print(i+" ");
        }
        Collections.sort(rollNumberList);
        System.out.println();
        System.out.println("After Sorting");
        for(Integer i:rollNumberList){
            System.out.print(i+" ");
        }


//        List<Student2>  list=new ArrayList<Student2>();
//        Student2 student1=new Student2(23,29);
//        Student2 student2=new Student2(21,30);
//        Student2 student3=new Student2(25,27);
//        list.add(student1);
//        list.add(student2);
//        list.add(student3);
//        Collections.sort(list);
//        System.out.println("Before Sorting");
//        for(Student2 i:list){
//            System.out.println("Age: "+i.getAge()+" Roll No: "+i.getRollNo());
//        }



    }


}
