package ca;

import java.lang.reflect.InvocationTargetException;

public class ObjectCreation3 implements ObjectCreateInterface {

    public void printHello(){
        System.out.println("Hello3");
    }



    public static void main(String[] args) throws IllegalAccessException, InstantiationException, ClassNotFoundException, NoSuchMethodException, InvocationTargetException {
        ObjectCreation3 objectCreation1=new ObjectCreation3();
        objectCreation1.printHello();

        ObjectCreation3 objectCreation2= ObjectCreation3.class.newInstance();
        objectCreation2.printHello();

        ObjectCreation3 objectCreation3= (ObjectCreation3) Class.forName("ca.ObjectCreation3").newInstance();
        objectCreation3.printHello();

            ObjectCreation3 objectCreation4=(ObjectCreation3) Class.forName("ca.ObjectCreation3").getConstructor().newInstance();
        objectCreation4.printHello();



    }
}
