package ca;

import java.lang.reflect.InvocationTargetException;

public class ObjectCreation4  implements ObjectCreateInterface{

    public void printHello(){
        System.out.println("Hello4");
    }





    public static void main(String[] args) throws IllegalAccessException, InstantiationException, ClassNotFoundException, NoSuchMethodException, InvocationTargetException {
        String one="ca.ObjectCreation";
        String two="ca.ObjectCreation2";
        String three="ca.ObjectCreation3";
        String four="ca.ObjectCreation4";


        ObjectCreateInterface objectCreateInterface=(ObjectCreateInterface)Class.forName(three).newInstance();
        objectCreateInterface.printHello();





    }
}
