package interview.string;

public class SubstringOfString {

    public static void main(String[] args) {
        getSubString("abcdef");
    }


    public static void getSubString(String str){

        if(str.length()==1){
            System.out.println(str);
            return;
        }

        getSubString(str.substring(1));
        for(int i=0;i<str.length();i++){
            System.out.println(str.substring(0,i+1));
        }

    }
}
