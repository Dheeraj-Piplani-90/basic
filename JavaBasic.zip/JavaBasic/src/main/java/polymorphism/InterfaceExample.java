package polymorphism;

public interface InterfaceExample {



    public void printHello();


}
