To provide the implementation of Functional interface.<br>
Less coding.<br>
Java Lambda Expression Syntax<br>
(argument-list) -> {body}  <br>
Java lambda expression is consisted of three components.

1) Argument-list: It can be empty or non-empty as well.

2) Arrow-token: It is used to link arguments-list and body of expression.

3) Body: It contains expressions and statements for lambda expression.