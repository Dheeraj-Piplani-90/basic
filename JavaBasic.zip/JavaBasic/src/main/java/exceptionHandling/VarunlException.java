package exceptionHandling;

public class VarunlException extends RuntimeException {


}
