package Generic.usecase;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Ddmmyy implements DateUtil {

    @Override
    public String extractDate(Date date) {
        SimpleDateFormat formatter1=new SimpleDateFormat("dd/MM/yyyy");
        return formatter1.format(date);
    }
}
