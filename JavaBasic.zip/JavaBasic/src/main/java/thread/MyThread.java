package thread;

public class MyThread extends Thread {

    public void run(){

        System.out.println(Thread.currentThread().getName());
//        for(int i=0;i<=10;i++){
//        }
//        System.out.println("Importnat job running in myTread");
    }

    public static void main(String[] args) {
        System.out.println(Thread.currentThread().getName());
        MyThread myThread=new MyThread();
        myThread.setName("Sunil");
        myThread.start();
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        MyThread myThread1=new MyThread();
        myThread1.setName("Sunil2");
        myThread1.start();

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        MyThread myThread2=new MyThread();
        myThread2.setName("Sunil3");
        myThread2.start();
    }

}
