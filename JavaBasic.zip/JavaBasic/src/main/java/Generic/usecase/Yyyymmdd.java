package Generic.usecase;

import java.util.Date;

public class Yyyymmdd implements DateUtil {

    public String extract(Date date){
        return "";
    }

    @Override
    public String extractDate(Date date) {
        return null;
    }
}
