package reflection;

public class Test {

    public static void main(String[] args) {

        String tableName="grs_t";
        String cloumn="emp_name";
    }
}
