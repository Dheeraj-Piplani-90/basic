package polymorphism;

import java.io.FileNotFoundException;

public class Test {


    public void division(InterfaceExample e) {
        e.printHello();
    }

    public static void main(String[] args) {
        Bike bike=new Bike();
        Test test=new Test();
        test.division(bike);
    }

}
