public class BankAccount {

    private long accountNumber;
    private String pan;
    private String owner;
    private String branch;
    private double balance;
    private double interestRate;


    public BankAccount(long accountNumber, String pan,String owner, double interestRate) {
        this.accountNumber = accountNumber;
        this.owner = owner;
        this.interestRate = interestRate;
    }

    public BankAccount(long accountNumber, String owner) {
        this.accountNumber = accountNumber;
        this.owner=owner;
    }

    public long getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(long accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }
}


