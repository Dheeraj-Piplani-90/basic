package interfaces;

import java.util.ArrayList;

public class Test {


    public static void main(String[] args) {
        Bike bike1 = new Avenger();
        Bike bike2 = new Splender();
        Bike bike3 = new Bullet();
        Honda bike4 = new Honda();
        ArrayList<Bike> arrayList = new ArrayList();
        arrayList.add(bike1);
        arrayList.add(bike2);
        arrayList.add(bike3);
        arrayList.add(bike4);
        printAllBikesName(arrayList);
    }


    public static void printAllBikesName(ArrayList<Bike> list) {
        for (Bike b : list) {
            b.pringName();
        }
    }
}
