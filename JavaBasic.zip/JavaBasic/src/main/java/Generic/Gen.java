package Generic;

public class Gen {

}
