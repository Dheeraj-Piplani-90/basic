package Generic;

public class MyClass extends Gen {
}
