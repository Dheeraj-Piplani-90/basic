package varun;

public class Avenger extends Bike {

    public  void printName(){
        System.out.println("My name is avenger");
    }

}
