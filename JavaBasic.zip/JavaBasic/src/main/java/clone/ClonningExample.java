package clone;

public class ClonningExample {

    public static void main(String[] args) throws CloneNotSupportedException {
        City city = new City("Dehradun");

        Person person1 = new Person("Naresh", 10000, city);


        Person person2 = person1.clone();

        System.out.println(person2);
//        person1.setName("Dheeraj");


        System.out.println(person2);
        if (person1 == person2) {
            System.out.println("Both person1 and person2 holds same object");
        }

//        if(person1.getName()==person2.getName()){
//            System.out.println("String refernce are equal");
//        }
//
//        if (person1.equals(person2)) {
//            System.out.println("But both person1 and person2 are equal and have same content");
//        }

        if (person1.getCity() == person2.getCity()) {
            System.out.println("Both person1 and person2 have same city object");
        }
    }
}
