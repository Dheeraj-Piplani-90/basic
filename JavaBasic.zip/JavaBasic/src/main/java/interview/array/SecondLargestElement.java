package interview.array;

public class SecondLargestElement {


    public static void main(String[] args) {
        int[] input={21,3,7,10,20};
        System.out.println("Second largest element is ---> "+secondLargest(input) );
    }

    public static int secondLargest(int[] input){

        int largest=0;
        int secondLargest=0;
        for(int i=0;i<input.length;i++){
            if(input[i]>largest){
                secondLargest=largest;
                largest=input[i];
            }
            else if(input[i]>secondLargest){
                secondLargest=input[i];
            }
        }

        return secondLargest;
    }
}
