package interfaces;

public class Avenger implements Bike {

    public void pringName(){
        System.out.println("My name is Avenger");
    }
}
