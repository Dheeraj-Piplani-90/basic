package datastructure.array;

import java.util.Arrays;

public class ArrayRotation {

    public static void main(String[] args) {
        int[] array={1,2,3,4,5,6,7};
//        printArray(array);
        rotateArray(2,array);
        printArray(array);
    }

    private static void rotateArray(int d, int[] arr){
        for(int i=0;i<d;i++){
            rotateArrayByOne(arr.length,arr);
        }
    }

    private static void rotateArrayByOne(int n,int[] arr){
        int i, temp;
        temp = arr[0];
        for (i = 0; i < n - 1; i++)
            arr[i] = arr[i + 1];
        arr[n-1] = temp;

    }


    private static void printArray(int[] array){

        Arrays.stream(array)
                .forEach(e->System.out.print(e + " "));
    }
}
