package exceptionHandling;

public class ExceptionTest {


    public void printHello(int y) throws ArithmeticException {
        try {
            int x = 0 / y;
        } catch (ArithmeticException e) {
            System.out.println("there is some error in y");
              throw  e;
        }

    }


    public static void main(String[] args) {

        try {
            int x = 0;
        } catch (ArithmeticException e) {
            System.out.println("Any Exception");
        } catch (Exception e) {
            System.out.println("IOException");
        } finally {
            System.out.println("Runiing finally block");
        }

        System.out.println("Morning sunil");
    }
}
