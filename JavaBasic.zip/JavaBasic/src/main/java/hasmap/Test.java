package hasmap;

import com.sun.xml.internal.ws.util.StringUtils;

import java.util.*;

public class Test {

    public static void main(String[] args) {

        Map<Integer,Integer> varunHashMap=new HashMap();
        varunHashMap.put(1,1);
        varunHashMap.put(1,2);
        varunHashMap.put(1,3);
        System.out.println(varunHashMap.size());
        varunHashMap.get(1);

//        Student student1=new Student(3);
//        Student student2=new Student(3);
//        Student student3=new Student(3);

//        Map<Student,Integer> stufentHashMap=new HashMap();
//        stufentHashMap.put(student1,1);
//        stufentHashMap.put(student2,2);
//        stufentHashMap.put(student3,3);

//        System.out.println(stufentHashMap.size());
//
//        System.out.println(student1.equals(student1));

        String s1=new String("Abc");
        String s2=new String("3");
        String s3=new String("3");

        Map<String,Integer> stringMap=new HashMap();
        stringMap.put(s1,1);
        stringMap.put(s2,2);
        stringMap.put(s3,3);
        System.out.println(s1.hashCode());
        System.out.println(s2.hashCode());
        System.out.println(stringMap.size());
        System.out.println(StringUtils.decapitalize(s1));
        }
    }


