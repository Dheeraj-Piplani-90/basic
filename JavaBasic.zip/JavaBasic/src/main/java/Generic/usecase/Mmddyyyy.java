package Generic.usecase;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Mmddyyyy implements DateUtil{
    @Override
    public String extractDate(Date date) {
        SimpleDateFormat formatter1=new SimpleDateFormat("MM/dd/yyyy");
        return formatter1.format(date);
    }
}
