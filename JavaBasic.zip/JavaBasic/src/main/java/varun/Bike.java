package varun;

public class Bike {

    public  void printName(){
        System.out.println("I do not know the bike name");
    }
}
