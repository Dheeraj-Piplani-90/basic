package Generic;

public class MyGen<Hello extends Gen> {
    Hello obj;


    void add(Hello obj){this.obj=obj;}

    Hello get(){return obj;}
}
