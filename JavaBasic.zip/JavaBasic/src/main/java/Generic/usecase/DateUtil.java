package Generic.usecase;

import java.util.Date;

public interface DateUtil {

    String extractDate(Date date);
}
