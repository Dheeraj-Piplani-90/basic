package exceptionHandling;

public class ExceptionThrowTest {


    public void  print(){
        ExceptionTest exceptionTest=new ExceptionTest();
        exceptionTest.printHello(0);
    }

}
