 <b>The Java Generics programming is introduced in J2SE 5 to deal with type-safe objects. It makes the code stable by detecting the bugs at compile time.</b>
 
 
 Type-safety: We can hold only a single type of objects in generics. It doesn?t allow to store other objects.
 
 Type casting is not required: There is no need to typecast the object.
 
  Compile-Time Checking: It is checked at compile time so problem will not occur at runtime. The good programming strategy says it is far better to handle the problem at compile time than runtime.