package polymorphism;

public class Bike2  implements InterfaceExample{
    public void printHello() {

        System.out.println("Bike2");
    }
}
