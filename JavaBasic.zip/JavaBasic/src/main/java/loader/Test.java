package loader;

public class Test {

    public static int z=1000;

    public static void main(String[] args) {
       Test test=null;
        System.out.println(test.z);
    }





}
