package polymorphism;

import java.io.FileNotFoundException;

public class Bike implements InterfaceExample  {


    public void printHello() {
        System.out.println("Bike");
    }
}
