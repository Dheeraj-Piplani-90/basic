package seriliaze;

// Java code for serialization and deserialization
// of a Java object
import java.io.*;



class Test {
    public static void main(String[] args) throws IOException {
//        Demo object = new Demo(1, "geeksforgeeks",'d');
        String filename = "file.ser";
//
//        // Serialization
//        try {
//            //Saving of object in a file
//            FileOutputStream file = new FileOutputStream(filename);
//            ObjectOutputStream out = new ObjectOutputStream(file);
//            // Method for serialization of object
//            out.writeObject(object);
//
//            out.close();
//            file.close();
//
//            System.out.println("Object has been serialized");
//
//        } catch (IOException ex) {
//            System.out.println("IOException is caught");
//        }

//
        Demo object1 = null;
        object1.d=12;
        FileInputStream file=null;
        ObjectInputStream in=null;

        // Deserialization
        try
        {
            // Reading the object from a file
          file = new FileInputStream(filename);
            in= new ObjectInputStream(file);

            // Method for deserialization of object
            object1 = (Demo)in.readObject();



            System.out.println("Object has been deserialized ");
            System.out.println("a = " + object1.a);
            System.out.println("b = " + object1.b);
            object1.d=13;
            System.out.println("d = " + object1.d);
            System.out.println("C = " + object1.c);
            System.out.println("y = " + object1.y);
            System.out.println("x = " + object1.x);
        }

        catch(IOException ex)
        {
            System.out.println("IOException is caught");
        }

        catch(ClassNotFoundException ex)
        {
            System.out.println("ClassNotFoundException is caught");
        }
        finally {
            in.close();
            file.close();
        }

    }
    }


